import socket

HOST = '0.0.0.0'
PORT = 6003 

storage_data = b''  

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(5)

print(f"[STORAGE] Running on {HOST}:{PORT}")

while True:
    conn, addr = server.accept()
    print(f"[STORAGE] Connected by {addr}")

    while True:
        cmd = conn.recv(1024).decode()
        if not cmd:
            break

       
        if cmd == 'store':
            conn.sendall(b'OK')

            size = int(conn.recv(1024).decode())
            conn.sendall(b'OK')

            received = 0
            chunk = b''

            while received < size:
                data = conn.recv(8192)
                if not data:
                    break
                chunk += data
                received += len(data)

            storage_data = chunk
            print(f"[STORAGE {PORT}] Stored chunk ({len(storage_data)} bytes)")

       
        elif cmd == 'get':
            conn.sendall(str(len(storage_data)).encode())
            conn.recv(1024)
            conn.sendall(storage_data)

            print(f"[STORAGE {PORT}] Sent chunk ({len(storage_data)} bytes)")

    conn.close()