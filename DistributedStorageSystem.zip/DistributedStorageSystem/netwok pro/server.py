import socket
import time

STORAGES = [
    ('192.168.4.116', 6001),
    ('192.168.4.238', 6002),
    ('192.168.4.115', 6003),
    ('192.168.4.73', 6004)
]

def split_file(data):
    size = len(data)
    chunk_size = size // 4
    return [
        data[0:chunk_size],
        data[chunk_size:chunk_size*2],
        data[chunk_size*2:chunk_size*3],
        data[chunk_size*3:]
    ]

def send_chunk(chunk, host, port):
    s = socket.socket()
    s.connect((host, port))
    s.sendall(b'store')
    s.recv(1024)
    s.sendall(str(len(chunk)).encode())
    s.recv(1024)
    s.sendall(chunk)
    s.close()
    print(f"[SERVER] Chunk sent to Storage {port}")

def get_chunk(host, port):
    s = socket.socket()
    s.connect((host, port))
    s.sendall(b'get')
    size = int(s.recv(1024).decode())
    s.sendall(b'OK')

    received = 0
    chunk = b''
    while received < size:
        data = s.recv(4096)
        if not data:
            break
        chunk += data
        received += len(data)

    s.close()
    print(f"[SERVER] Chunk received from Storage {port}")
    return chunk

server = socket.socket()
server.bind(("0.0.0.0", 5000))
server.listen(1)

print("[SERVER] Waiting for client...")

while True:
    client, addr = server.accept()
    print("[SERVER] Client connected:", addr)

    file_size = int(client.recv(1024).decode())
    client.sendall(b'OK')

    received = 0
    file_data = b''
    while received < file_size:
        data = client.recv(4096)
        if not data:
            break
        file_data += data
        received += len(data)

    print("[SERVER] File received")

   
    chunks = split_file(file_data)
    for chunk, (host, port) in zip(chunks, STORAGES):
        send_chunk(chunk, host, port)

    print("[SERVER] Waiting for client request...")

    request = client.recv(1024).decode()
    print("[SERVER] Client request:", request)

    if request == "GET_FILE":
        returned_chunks = [get_chunk(host, port) for host, port in STORAGES]
        final_file = b''.join(returned_chunks)

        client.sendall(str(len(final_file)).encode())
        client.recv(1024)
        client.sendall(final_file)

        print("[SERVER] Final file sent to client")

    client.close()
    print("[SERVER] Client disconnected\n")