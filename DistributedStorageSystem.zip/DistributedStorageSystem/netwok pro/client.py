import socket
import os

SERVER_IP = '192.168.4.64'
SERVER_PORT = 5000

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((SERVER_IP, SERVER_PORT))
print("[CLIENT] Connected to server")


filename = input("Enter the file to send: ").strip('"')

if not os.path.exists(filename):
    print("File not found")
    client.close()
    exit()

filesize = os.path.getsize(filename)
client.sendall(str(filesize).encode())
client.recv(1024)

with open(filename, 'rb') as f:
    client.sendfile(f)

print("File sent successfully")

choice = input("Do you want to receive the file back from server? (y/n): ").lower()

if choice == 'y':
    client.sendall(b'GET_FILE')

    data = client.recv(1024).decode()
    if not data:
        print("Server did not send file size")
        client.close()
        exit()

    merged_size = int(data)
    client.sendall(b'OK')

    received = 0
    output_file = "final_file_from_server.bin"

    with open(output_file, 'wb') as f:
        while received < merged_size:
            chunk = client.recv(4096)
            if not chunk:
                break
            f.write(chunk)
            received += len(chunk)

    print("File received successfully")
    os.startfile(output_file)

else:
    client.sendall(b'NO')
    print("User chose not to receive the file")

client.close()