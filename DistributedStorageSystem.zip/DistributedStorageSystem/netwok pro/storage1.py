import socket

HOST = '0.0.0.0'   # accept any conneection from any ip 
PORT = 6001   

storage_data = b''    # place that stored chunks in bytes

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))   # bind server with addr
server.listen(5)

print(f"[STORAGE] Running on {HOST}:{PORT}")

while True:  # listen all the time 
    conn, addr = server.accept()     #  conn ->socket  addr -> ip,port 
    print(f"[STORAGE] Connected by {addr}")

    while True:  # the same connectionممكن يتبعت اكتر من امره
        cmd = conn.recv(1024).decode()  # decode bc (recv return bytes but we need srtings)
        if not cmd:                     # اكونيكشن اتقفل اكلع بره اللوب
            break

        # السيرفر الرئيسى هيبعت   store / Get
        if cmd == 'store':                                             # السيرفر الرئيسى جاى يسيب حاجه عندى   
            conn.sendall(b'OK')

            size = int(conn.recv(1024).decode())                # decode bc (recv return bytes but we need srtings)
            conn.sendall(b'OK')                                  #  say ready means ابعت الحجم 

            received = 0
            chunk = b''
 
            while received < size:                 # لسه فيه بيانات ناقصه
                data = conn.recv(8192)             # استقبل جزء صغير
                if not data:
                    break
                chunk += data                        # collect
                received += len(data)

            storage_data = chunk                       # part->storeed رسميا
            print(f"[STORAGE {PORT}] Stored chunk ({len(storage_data)} bytes)")

       
        elif cmd == 'get':
            conn.sendall(str(len(storage_data)).encode())
            conn.recv(1024)
            conn.sendall(storage_data)

            print(f"[STORAGE {PORT}] Sent chunk ({len(storage_data)} bytes)")

    conn.close()